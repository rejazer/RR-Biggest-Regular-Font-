# web-presentation

Project is designed to quickly build presentation as a web page.

To create your presentation just fork this repository.

presentation example https://deepidea.github.io/web-presentation/


**NOTES**

- Files names should start with valid  year-month-day format (f.e. 1000-01-01-example.md)

- Years will be displayed horizontally  

- Months will be displayed as vertical navigation in a given year

- Presentation pages will be displayed in chronological order

- GitHub Pages will automatically generate/update website with presentation for you (please wait up to 1 minute)


Enjoy
